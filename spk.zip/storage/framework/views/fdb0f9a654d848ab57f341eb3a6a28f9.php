
<?php $__env->startSection('title', 'Dashboard'); ?>
<?php $__env->startPush('style'); ?>
<?php $__env->stopPush(); ?>
<?php $__env->startSection('main'); ?>
    <div class="d-sm-flex align-items-center justify-content-between mb-4">
        <h1 class="h4 mb-0 text-bold-gray-800"><i class="fas fa-fw fa-folder"></i> Data Kriteria</h1>
        

        <a href="<?php echo e(route('createKriteria')); ?>" class="btn btn-sm btn-dark"> Tambah Kriteria </a>
    </div>
    <div class="card shadow mb-4">


        <div class="card-body">
            <div class="table-responsive">
                <table id="" class="table  table-bordered table-lg" width="100%" cellspacing="0">
                    <thead class="text-black">
                        <tr align="center">
                            <th style="width: 3%">No</th>
                            <th>Kode Kriteria</th>
                            <th>Nama Kriteria</th>
                            <th>Jenis Kriteria</th>
                            <th>Bobot Kriteria</th>
                            <th width="15%">Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $kriterias; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $kriteria): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr align="center">
                                <td><?php echo e($loop->iteration); ?></td>
                                <td><?php echo e($kriteria->kode_kriteria); ?></td>
                                <td><?php echo e($kriteria->nama); ?></td>
                                <td><?php echo e($kriteria->type); ?></td>
                                <td><?php echo e($kriteria->bobot); ?></td>
                                <td>
                                    <div class="btn-group" role="group">
                                        <a data-toggle="tooltip" data-placement="bottom" title="Edit Data"
                                            href="<?php echo e(route('editKriteria', $kriteria)); ?>"
                                            class="btn btn-warning btn-sm btn rounded mr-2"><i class="fa fa-edit"></i></a>
                                        <form action="<?php echo e(route('deleteKriteria', $kriteria)); ?>" method="post">
                                            <?php echo method_field('delete'); ?>
                                            <?php echo csrf_field(); ?>
                                            <button data-toggle="tooltip" data-placement="bottom" title="Hapus Data"
                                                onclick="return confirm ('Apakah anda yakin untuk meghapus data ini')"
                                                class="btn btn-danger btn-sm"><i class="fa fa-trash"></i>
                                            </button>
                                        </form>
                                    </div>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('script'); ?>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\spk\resources\views/kriteria/indexKriteria.blade.php ENDPATH**/ ?>