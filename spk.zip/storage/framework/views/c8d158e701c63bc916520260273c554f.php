
<?php $__env->startSection('title', 'Hasil'); ?>
<?php $__env->startPush('style'); ?>
<?php $__env->stopPush(); ?>
<?php $__env->startSection('main'); ?>
    <div class="d-sm-flex align-items-center justify-content-between mb-4">
        <h1 class="h4 mb-0 text-gray-800">Data Hasil Akhir</h1>
        <a href="<?php echo e(route('exportHasil')); ?>" target="_blank" class="btn btn-sm btn-dark"> <i class="fa fa-print"></i> Export
            Excel</a>
    </div>

    <div class="card shadow mb-4">
        <div class="card-body">
            <div class="table-responsive">
                <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                    <thead class=" text-black">
                        <tr align="center">
                            <th>Nama Alternatif</th>
                            <th>Nilai</th>
                            <th width="15%">Rank</th>
                        </tr>
                    </thead>
                    <tbody>
                    <?php $__currentLoopData = $hasils; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $hasil): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr align="center">
                            <td align="left"><?php echo e($hasil->Alternatif->nama); ?></td>
                            <td><?php echo e($hasil->nilai); ?></td>
                            <td><?php echo e($hasil->rank); ?></td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('script'); ?>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\fadel\Downloads\spk\resources\views/hasil/indexHasil.blade.php ENDPATH**/ ?>