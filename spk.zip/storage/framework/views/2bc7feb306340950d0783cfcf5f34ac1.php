<?php
    use App\Models\Penilaian;
    use App\Models\SubKriteria;
?>

<?php $__env->startSection('title', 'Dashboard'); ?>
<?php $__env->startPush('style'); ?>
<?php $__env->stopPush(); ?>
<?php $__env->startSection('main'); ?>
    <div class="d-sm-flex align-items-center justify-content-between mb-4">
        <h1 class="h4 mb-0 text-gray-800">Data Penilaian</h1>
    </div>
    <div class="card shadow mb-4">
        <div class="card-body">
            <div class="table-responsive">
                <table class="table table-bordered" width="100%" cellspacing="0" id="dataTable">
                    <thead class=" text-black">
                        <tr align="center">
                            <th style="width: 3%">No</th>
                            <th>Nama Alternatif</th>
                            <th width="15%">Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $dataAlternatifs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dataAlternatif): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr align="center">
                                <td><?php echo e($loop->iteration); ?></td>
                                <td><?php echo e($dataAlternatif->nama); ?></td>
                                <td>
                                    <?php if($dataAlternatif->Penilaian->count() == 0): ?>
                                        <a data-toggle="modal" title="input Data"
                                            href="#inputpenialaian<?php echo e($dataAlternatif->id); ?>"
                                            class="btn btn-success btn-sm btn rounded mr-2"><i class="fa fa-plus"></i></a>
                                    <?php else: ?>
                                        <a data-toggle="modal" title="Edit Data"
                                            href="#editpenilaian<?php echo e($dataAlternatif->id); ?>"
                                            class="btn btn-warning btn-sm btn rounded mr-2"><i class="fa fa-eye"></i></a>
                                    <?php endif; ?>
                                </td>
                            </tr>

                            <div class="modal fade bd-example-modal-lg" id="inputpenialaian<?php echo e($dataAlternatif->id); ?>"
                                tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
                                <div class="modal-dialog modal-lg">
                                    <div class="modal-content">
                                        <div class="modal-header">
                                            <h5 class="modal-title" id="myModalLabel">
                                                Tambah Penilaian</h5>
                                            <button type="button" class="close" data-dismiss="modal"
                                                aria-hidden="true">&times;</button>
                                        </div>
                                        <form action="<?php echo e(route('storePenilaian', $dataAlternatif)); ?>" method="post">
                                            <?php echo csrf_field(); ?>
                                            <div class="modal-body">
                                                <div class="row">
                                                    <?php $__currentLoopData = $dataKriterias; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dataKriteria): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <div class="form-group col-12 col-md-6">
                                                            <label class="font-weight-bold"><?php echo e($dataKriteria->nama); ?>

                                                                (<?php echo e($dataKriteria->kode_kriteria); ?>)
                                                            </label>
                                                            <input type="hidden" name="kriteria_id[]" class="form-control"
                                                                value="<?php echo e($dataKriteria->id); ?>">
                                                            <select name="nilai[]" class="form-control" required>
                                                                <option value="">Pilih nilai kriteria</option>
                                                                <?php $__currentLoopData = $dataKriteria->Subkriteria; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $Subkriteria): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                    <option value="<?php echo e($Subkriteria->id); ?>">
                                                                        <?php echo e($Subkriteria->nama); ?>

                                                                    </option>
                                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                            </select>
                                                        </div>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </div>
                                            </div>
                                            <div class="modal-footer">
                                                <button type="button" class="btn btn-warning" data-dismiss="modal"><i
                                                        class="fa fa-times"></i>
                                                    Batal</button>
                                                <button type="submit" name="edit" class="btn btn-success"><i
                                                        class="fa fa-save"></i>
                                                    Simpan</button>
                                            </div>
                                        </form>
                                    </div>
                                </div>
                            </div>

                            <div class="modal fade" id="editpenilaian<?php echo e($dataAlternatif->id); ?>" tabindex="-1"
                                role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
                                <div class="modal-dialog modal-dialog modal-lg">
                                    <div class="modal-content">
                                        <div class="modal-header">
            
                                            <button type="button" class="close" data-dismiss="modal"
                                                aria-hidden="true">&times;</button>
                                        </div>
                                        <div class="modal-body">
                                            <div class="row">
                                                <?php $__currentLoopData = $dataKriterias; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dataKriteria): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <?php
                                                        $id_alternatif = $dataAlternatif->id;
                                                        $penilaian = Penilaian::where('alternatif_id', $id_alternatif)
                                                            ->where('kriteria_id', $dataKriteria->id)
                                                            ->first();
                                                    ?>
                                                    <div class="form-group col-12 col-md-6">
                                                        <label class="font-weight-bold m-0"><?php echo e($dataKriteria->nama); ?>

                                                            (<?php echo e($dataKriteria->kode_kriteria); ?>)
                                                        </label>
                                                        <?php if($penilaian && !is_null($penilaian->nilai)): ?>
                                                            <h6 class="font-weight-light" style="font-size: 12px">
                                                                Dinilai Oleh :
                                                                <?php echo e($penilaian->User->nama); ?></h6>
                                                        <?php else: ?>
                                                            <h6 class="font-weight-light" style="font-size: 12px">
                                                                Tidak Dinilai.
                                                        <?php endif; ?>
                                                        <input type="text" class="form-control" name="kriteria_id[]"
                                                            value="<?php echo e($dataKriteria->id); ?>" hidden>
                                                        <?php $__currentLoopData = $dataKriteria->SubKriteria; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $subKriteria): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <?php if($penilaian && !is_null($penilaian->nilai)): ?>
                                                                <?php if($subKriteria->id == $penilaian->sub_kriteria_id): ?>
                                                                    <input type="text" name="" id=""
                                                                        class="form-control"
                                                                        value="<?php echo e($subKriteria->nama); ?>" required readonly>
                                                                <?php endif; ?>
                                                            <?php endif; ?>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    </div>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </div>
                                        </div>
                                        <div class="modal-footer">
                                            <button type="button" class="btn btn-sm btn-warning" data-dismiss="modal"><i
                                                    class="fa fa-times"></i>
                                                Batal</button>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('script'); ?>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\fadel\Downloads\spk\resources\views/penilaian/indexPenilaian.blade.php ENDPATH**/ ?>