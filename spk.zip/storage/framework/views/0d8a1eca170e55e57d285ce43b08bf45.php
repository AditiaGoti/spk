 <!-- Bootstrap core JavaScript-->
 <script src="<?php echo e(asset('assets/vendor/bootstrap/js/bootstrap.bundle.min.js')); ?>"></script>

 <!-- Core plugin JavaScript-->
 <script src="<?php echo e(asset('assets/vendor/jquery-easing/jquery.easing.min.js')); ?>"></script>

 <!-- Custom scripts for all pages-->
 <script src="<?php echo e(asset('assets/js/sb-admin-2.min.js')); ?>"></script>

 <!-- Page level plugins -->
 <script src="<?php echo e(asset('assets/vendor/chart.js/Chart.min.js')); ?>"></script>

 <!-- Page level plugins -->
 <script src="<?php echo e(asset('assets/vendor/datatables/jquery.dataTables.min.js')); ?>"></script>
 <script src="<?php echo e(asset('assets/vendor/datatables/dataTables.bootstrap4.min.js')); ?>"></script>

 <!-- Page level custom scripts -->
 <script src="<?php echo e(asset('assets/js/demo/datatables-demo.js')); ?>"></script>

 <script>
     $(function() {
         $('[data-toggle="tooltip"]').tooltip()
     })
 </script>
<?php /**PATH C:\xampp\htdocs\spk\resources\views/components/dashboard/_scripts.blade.php ENDPATH**/ ?>