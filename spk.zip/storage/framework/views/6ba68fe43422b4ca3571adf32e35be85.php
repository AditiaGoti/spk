
<?php $__env->startSection('title', 'Dashboard'); ?>
<?php $__env->startPush('style'); ?>
<?php $__env->stopPush(); ?>
<?php $__env->startSection('main'); ?>
    <?php if($subkriterias->count() <= 0): ?>
        <p>Data Tidak Ditemukan</p>
    <?php else: ?>
        <?php $__currentLoopData = $subkriterias; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subkriteria): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="card shadow mb-4">
                <!-- /.card-header -->
                <div class="card-header py-3">
                    <div class="d-sm-flex align-items-center justify-content-between">
                        <h6 class="m-0 font-weight-bold text-black">
                            <?php echo e($subkriteria->kode_kriteria . ' - ' . $subkriteria->nama); ?></h6>

                        <a href="#tambah<?php echo e($subkriteria->id); ?>" data-toggle="modal" class="btn btn-sm btn-dark">
                            Tambah nilai kriteria </a>
                    </div>
                </div>

                <div class="modal fade" id="tambah<?php echo e($subkriteria->id); ?>" tabindex="-1" role="dialog"
                    aria-labelledby="myModalLabel" aria-hidden="true">
                    <div class="modal-dialog">
                        <div class="modal-content">
                            <div class="modal-header">
                                <h5 class="modal-title" id="myModalLabel"> Tambah Nilai Kriteria
                                </h5>
                                <button type="button" class="close" data-dismiss="modal"
                                    aria-hidden="true">&times;</button>
                            </div>
                            <form action="<?php echo e(route('storeSubKriteria', $subkriteria)); ?>" method="post">
                                <?php echo csrf_field(); ?>
                                <div class="modal-body">
                                    <input type="text" name="id_kriteria" value="" hidden>
                                    <div class="form-group">
                                        <label class="font-weight-bold">Nama</label>
                                        <input autocomplete="off" type="text"class="form-control" name="nama"
                                            required>
                                    </div>
                                    <div class="form-group">
                                        <label class="font-weight-bold">Nilai</label>
                                        <input autocomplete="off" step="0.001" type="number" name="nilai"
                                            class="form-control" required>
                                    </div>
                                </div>
                                <div class="modal-footer">
                                    <button type="button" class="btn btn-sm btn-warning" data-dismiss="modal"> Batal</button>
                                    <button type="submit" name="tambah" class="btn btn-sm btn-success">
                                        Tambah</button>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>

                <div class="card-body">
                    <div class="table-responsive">
                        <table class="table table-bordered" width="100%" cellspacing="0">
                            <thead class=" text-black">
                                <tr align="center">
                                    <th width="3%">No</th>
                                    <th>Nama</th>
                                    <th>Nilai</th>
                                    <th width="15%">Action</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $subkriteria->SubKriteria; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $SubKriteria): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr align="center">
                                        <td><?php echo e($loop->iteration); ?></td>
                                        <td><?php echo e($SubKriteria->nama); ?></td>
                                        <td><?php echo e($SubKriteria->nilai); ?></td>
                                        <td>
                                            <div class="btn-group" role="group">
                                                <a data-toggle="modal" title="Edit Data"
                                                    href="#editsk<?php echo e($SubKriteria->id); ?>"
                                                    class="btn btn-warning btn-sm btn rounded mr-2"><i
                                                        class="fa fa-edit"></i></a>

                                                <form action="<?php echo e(route('deleteSubKriteria', $SubKriteria)); ?>"
                                                    method="post">
                                                    <?php echo method_field('delete'); ?>
                                                    <?php echo csrf_field(); ?>
                                                    <button data-toggle="tooltip" data-placement="bottom" title="Hapus Data"
                                                        onclick="return confirm ('Apakah anda yakin untuk meghapus data ini')"
                                                        class="btn btn-danger btn-sm"><i class="fa fa-trash"></i>
                                                    </button>
                                                </form>
                                            </div>
                                        </td>
                                    </tr>




                                    <!-- Modal -->
                                    <div class="modal fade" id="editsk<?php echo e($SubKriteria->id); ?>" tabindex="-1" role="dialog"
                                        aria-labelledby="myModalLabel" aria-hidden="true">
                                        <div class="modal-dialog">
                                            <div class="modal-content">
                                                <div class="modal-header">
                                                    <h5 class="modal-title" id="myModalLabel"><i class="fa fa-edit"></i>
                                                        Edit
                                                        <?php echo e($SubKriteria->nama); ?></h5>
                                                    <button type="button" class="close" data-dismiss="modal"
                                                        aria-hidden="true">&times;</button>
                                                </div>
                                                <form action="<?php echo e(route('updateSubKriteria', $SubKriteria)); ?>"
                                                    method="post">
                                                    <?php echo method_field('patch'); ?>
                                                    <?php echo csrf_field(); ?>
                                                    <div class="modal-body">
                                                        <div class="form-group">
                                                            <label class="font-weight-bold">Nama</label>
                                                            <input type="text" autocomplete="off" class="form-control"
                                                                value="<?php echo e($SubKriteria->nama); ?>" name="nama" required>
                                                        </div>
                                                        <div class="form-group">
                                                            <label class="font-weight-bold">Nilai</label>
                                                            <input type="number" step="0.001" autocomplete="off"
                                                                name="nilai" class="form-control"
                                                                value="<?php echo e($SubKriteria->nilai); ?>" required>
                                                        </div>
                                                    </div>
                                                    <div class="modal-footer">
                                                        <button type="button" class="btn btn-sm btn-warning"
                                                            data-dismiss="modal">
                                                            Batal</button>
                                                        <button type="submit" name="edit"
                                                            class="btn btn-sm  btn-success"><i class="fa fa-save"></i>
                                                            Update</button>
                                                    </div>
                                                </form>
                                            </div>
                                        </div>
                                    </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    <?php endif; ?>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('script'); ?>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\spk\resources\views/subkriteria/indexSubKriteria.blade.php ENDPATH**/ ?>